from flask import Flask, render_template, request
from ultralytics import YOLO
from PIL import Image
import os

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

model = YOLO("best.pt")

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        if 'image' not in request.files:
            return render_template("index.html", error="Vui lòng tải lên một tệp hình ảnh.")

        file = request.files["image"]
        if file.filename == "":
            return render_template("index.html", error="Chưa chọn tệp hình ảnh.")
        
        if not file.filename.lower().endswith(".jpg"):
            return render_template("index.html", error="Vui lòng chỉ chọn ảnh đuôi .jpg")

        img_path = os.path.join(UPLOAD_FOLDER, "original.jpg")
        file.save(img_path)

        # Resize ảnh về 640x640
        image = Image.open(img_path)
        image = image.resize((640, 640))
        image.save(img_path)

        # Dự đoán bằng YOLOv8
        results = model.predict(source=img_path, save=True, project=UPLOAD_FOLDER, name="result", exist_ok=True)

        # Di chuyển ảnh kết quả về thư mục đúng
        result_img_path = os.path.join(UPLOAD_FOLDER, "result", "original.jpg")
        final_result_path = os.path.join(UPLOAD_FOLDER, "result.jpg")
        if os.path.exists(result_img_path):
            os.replace(result_img_path, final_result_path)

        return render_template("index.html", original="uploads/original.jpg", result="uploads/result.jpg")

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
